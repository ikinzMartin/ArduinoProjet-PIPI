ֻ�ܴ�һ�ִ�����������
cquisition_board.ino is a complete code, After Run it , all of the sensors data is uploaded toDevicebit platform.
To facilitate understanding , this code has been split. 
For example Humiture_sensor is to upload the data of Humiture sensor to the devicebie platform .
which will be faster to upload data ,the disadvantage is that you can only transfer a sensor's data. 