1.You may need to install the driver of the nano board,it detail information please refer to
 https://www.sunfounder.com/wiki/index.php?title=SunFounder_Nano_Board

2.The fritzing breadboard images are drawn in Fritzing software. You may go to their official website to download the latest version. 

http://fritzing.org/download/

3. The code is for Arduino. You can download Arduino IDE 
 https://www.arduino.cc/en/Main/Software. 
 
4.If you have questions for the code, you can refer this website
 https://www.arduino.cc/en/Reference/HomePage. 