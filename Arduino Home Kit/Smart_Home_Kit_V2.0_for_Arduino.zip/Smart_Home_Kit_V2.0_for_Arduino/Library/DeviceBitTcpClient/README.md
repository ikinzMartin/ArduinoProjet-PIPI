DeviceBitTcpClient
==================

arduino library,enable your sensors and devices talking to devicebit.com via TCP method,customized your control functions.
